"""Package tracked lab files, extract them elsewhere, and verify the clean copy."""
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent


def main() -> None:
    names = [line.split("  ", 1)[1] for line in
             (ROOT / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines()]
    names.append("SHA256SUMS.txt")
    with tempfile.TemporaryDirectory(prefix="chapter3-clean-") as raw:
        scratch = Path(raw)
        archive = scratch / "chapter3-lab.zip"
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
            for name in names:
                bundle.write(ROOT / name, "lab/" + name)
        with zipfile.ZipFile(archive) as bundle:
            if bundle.testzip() is not None:
                raise AssertionError("ZIP member integrity failed")
            bundle.extractall(scratch / "extracted")
        extracted = scratch / "extracted/lab"
        environment = dict(os.environ)
        environment.pop("PYTHONPATH", None)
        environment["PYTHONNOUSERSITE"] = "1"
        # The working directory contains neither the extracted module nor any
        # sibling foundation lab; imports must come from the packaged script.
        result = subprocess.run([sys.executable, str(extracted / "verify_lab.py")],
                                cwd=scratch, env=environment, capture_output=True,
                                text=True, check=True)
        verification = json.loads(result.stdout)
        report = {"status": "passed", "archive_files": len(names),
                  "extraction_verified": True, "pythonpath_removed": True,
                  "unit_tests_run": verification["unit_tests_run"],
                  "verification": verification,
                  "manifest_sha256": sha256((ROOT / "SHA256SUMS.txt").read_bytes()).hexdigest()}
    target = ROOT / "generated"
    target.mkdir(exist_ok=True)
    text = json.dumps(report, indent=2, sort_keys=True) + "\n"
    (target / "clean_extraction.json").write_text(text, encoding="utf-8")
    print(text, end="")


if __name__ == "__main__":
    main()
