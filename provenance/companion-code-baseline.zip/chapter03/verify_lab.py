"""Verify checksums, vendored inputs, exact listings, exercises, SQL, and tests.

Only generated/ is written. Expected outputs and checksums are never rewritten.
Use the same command in an extracted copy; no parent directories are imported.
"""
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import platform
import sqlite3
import subprocess
import sys
import unittest

from exercise_answers import answers
from export_sql import standalone_script
from generated_checks import run_checks
from historical_lab import Query, example_report, load_fixture
from printed_examples import run_examples
from run_sql_file import run_file

ROOT = Path(__file__).resolve().parent


def encoded(value) -> str:
    return json.dumps(value, indent=2, sort_keys=True) + "\n"


def check_manifest() -> int:
    count = 0
    for line in (ROOT / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", 1)
        path = ROOT / name
        if path.resolve().parent != ROOT and ROOT not in path.resolve().parents:
            raise AssertionError("manifest path escapes lab")
        if sha256(path.read_bytes()).hexdigest() != expected:
            raise AssertionError(f"checksum mismatch: {name}")
        count += 1
    return count


def check_vendor() -> int:
    data = json.loads((ROOT / "vendor_hashes.json").read_text(encoding="utf-8"))
    for item in data["files"]:
        if sha256((ROOT / item["vendored_path"]).read_bytes()).hexdigest() != item["sha256"]:
            raise AssertionError(f"vendored file changed: {item['vendored_path']}")
    return len(data["files"])


def check_cli() -> list[dict]:
    commands = [(["sqlite_lab.py"], "50\n"),
                (["sqlite_lab.py", "--known-at", "610"], "85\n"),
                (["sqlite_lab.py", "--window-start", "550", "--window-end", "610", "--known-at", "610"], "95\n"),
                (["sqlite_lab.py", "--unknown-history"], "null\n"),
                (["run_sql_file.py"], "50\n")]
    results = []
    for args, expected in commands:
        result = subprocess.run([sys.executable, *args], cwd=ROOT, text=True,
                                capture_output=True, check=True)
        if result.stdout != expected:
            raise AssertionError((args, result.stdout, expected))
        results.append({"command": "python " + " ".join(args), "stdout": result.stdout})
    return results


def main() -> None:
    digests = check_manifest()
    vendors = check_vendor()
    generated = ROOT / "generated"
    generated.mkdir(exist_ok=True)
    capture = StringIO()
    suite = unittest.defaultTestLoader.discover(str(ROOT), pattern="test_*.py")
    result = unittest.TextTestRunner(stream=capture, verbosity=2).run(suite)
    (generated / "unittest.log").write_text(capture.getvalue(), encoding="utf-8")
    if not result.wasSuccessful():
        print(capture.getvalue(), file=sys.stderr)
        raise SystemExit("Unit tests failed")
    exported = standalone_script(load_fixture(), Query("C1", 540, 600, 600))
    if exported != (ROOT / "standalone_example.sql").read_text(encoding="utf-8"):
        raise AssertionError("standalone SQL export drifted from the canonical fixture")
    if run_file(ROOT / "standalone_example.sql") != ["50"]:
        raise AssertionError("standalone SQL produced the wrong value")
    reports = {"examples.json": example_report(), "exercise_answers.json": answers(),
               "printed_examples.json": run_examples(), "generated_checks.json": run_checks(),
               "cli_commands.json": check_cli()}
    for name, report in reports.items():
        actual = encoded(report)
        (generated / name).write_text(actual, encoding="utf-8")
        if actual != (ROOT / "expected_outputs" / name).read_text(encoding="utf-8"):
            raise AssertionError(f"snapshot mismatch: {name}")
    summary = {"status": "passed", "unit_tests_run": result.testsRun,
               "unit_test_failures": len(result.failures), "unit_test_errors": len(result.errors),
               "printed_snippets_executed": reports["printed_examples.json"]["snippets_executed"],
               "exercises_executed": len(reports["exercise_answers.json"]),
               "checksum_files_verified": digests, "vendor_files_verified": vendors,
               "snapshot_files_verified": sorted(reports), "cli_commands_verified": len(reports["cli_commands.json"]),
               "standalone_sql_verified": True, "generated_checks": reports["generated_checks.json"],
               "python_version": platform.python_version(), "sqlite_version": sqlite3.sqlite_version,
               "scope": "Synthetic source-knowledge reconstruction, not proof of online served values."}
    text = encoded(summary)
    (generated / "verification.json").write_text(text, encoding="utf-8")
    print(text, end="")


if __name__ == "__main__":
    main()
