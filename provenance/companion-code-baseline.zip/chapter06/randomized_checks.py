"""Seeded independent oracles for reference, policy, sink, and cache semantics.

Oracles use plain dictionaries and exhaustive integer-time scans. They never
call the implementation's reference, publication builder, or snapshot methods.
Counts report comparisons actually executed, not a requested target count.
"""

from collections import Counter
from dataclasses import asdict
import random

from parity_lab import (CacheTimeline, FeatureKey, SourceHistory, SourceRevision,
                        StoreTimeline, build_publications, canonical_json)

SEED = 20261003
CASES = 128


def oracle_reference(rows: list[dict], key: FeatureKey, cutoff: int) -> tuple:
    chosen = []
    for event_id in sorted({row["source_event_id"] for row in rows}):
        eligible = [row for row in rows if row["source_event_id"] == event_id
                    and row["available_at"] <= cutoff]
        if eligible:
            winner = max(eligible, key=lambda row: row["revision"])
            if winner["entity"] == key.entity and key.window_start <= winner["event_time"] < key.window_end:
                chosen.append(winner)
    return (sum(row["amount"] for row in chosen),
            tuple((row["source_event_id"], row["revision"]) for row in chosen))


def oracle_publications(rows: list[dict], key: FeatureKey, initial: int, deadline: int) -> list[dict]:
    output = []
    for minute in range(initial, deadline + 1):
        value, versions = oracle_reference(rows, key, minute)
        if not output or versions != output[-1]["source_versions"]:
            output.append({"revision": len(output) + 1, "published_at": minute,
                           "source_cutoff": minute, "value": value, "source_versions": versions})
    return output


def oracle_store(publications: list[dict], deliveries: list[tuple[int, int]], minute: int) -> dict | None:
    eligible = [revision for visible_at, revision in deliveries if visible_at <= minute]
    if not eligible:
        return None
    revision = max(eligible)
    return next(row for row in publications if row["revision"] == revision)


def signature(record) -> tuple | None:
    return None if record is None else (record.revision, record.value, record.source_cutoff, record.source_versions)


def oracle_signature(record: dict | None) -> tuple | None:
    return None if record is None else (record["revision"], record["value"], record["source_cutoff"], record["source_versions"])


def run_checks(*, cases: int = CASES, seed: int = SEED) -> dict:
    rng = random.Random(seed)
    counts: Counter[str] = Counter()
    for case in range(cases):
        key = FeatureKey("oracle-fixed-window-v1", "immediate_then_correct", "C1", 100, 160)
        revisions = []
        for event in range(8):
            event_time = rng.choice([99, 100, 101, 159, 160, 161, rng.randrange(90, 171)])
            entity = rng.choice(["C1", "C1", "C1", "OTHER"])
            for revision in range(1, rng.randrange(2, 5)):
                revisions.append(SourceRevision(f"event-{event}", revision, entity, event_time,
                                                max(event_time, rng.randrange(140, 181)), rng.randrange(0, 51)))
        # Idempotent source retries and out-of-order input are both intentional.
        deliveries = revisions + rng.sample(revisions, k=min(4, len(revisions)))
        rng.shuffle(deliveries)
        history = SourceHistory(deliveries)
        plain_rows = [asdict(row) for row in revisions]
        query_times = sorted({99, 100, 159, 160, 169, 170, 171, 200,
                              *(row.available_at + offset for row in revisions for offset in (-1, 0, 1))})
        for cutoff in query_times:
            expected = oracle_reference(plain_rows, key, cutoff)
            actual = history.reference(key, cutoff)
            assert (actual.value, actual.source_versions) == expected, (case, cutoff, "reference")
            counts["reference_comparisons"] += 1
        expected_publications = oracle_publications(plain_rows, key, 160, 170)
        publications = build_publications(history, key, initial_at=160, deadline=170)
        assert [signature(row) for row in publications] == [oracle_signature(row) for row in expected_publications]
        counts["publication_sequence_comparisons"] += 1
        for _ in range(3):
            rng.shuffle(deliveries)
            reordered = build_publications(SourceHistory(deliveries), key, initial_at=160, deadline=170)
            assert reordered == publications, (case, "source reorder")
            counts["reordered_source_comparisons"] += 1
        sink_deliveries = [(row.published_at + rng.randrange(0, 13), row.revision) for row in publications]
        sink_deliveries += [(at + rng.randrange(0, 8), revision) for at, revision in sink_deliveries[:2]]
        rng.shuffle(sink_deliveries)
        store = StoreTimeline.from_deliveries(publications, sink_deliveries)
        refreshes = sorted({159, 161, 169, 178, *(rng.randrange(159, 186) for _ in range(6))})
        cache = CacheTimeline.from_refreshes(store, refreshes)
        request_times = sorted({158, 159, 160, 170, 200,
                                *(at + offset for at, _ in sink_deliveries for offset in (-1, 0, 1)),
                                *(at + offset for at in refreshes for offset in (-1, 0, 1))})
        for minute in request_times:
            expected_store = oracle_store(expected_publications, sink_deliveries, minute)
            assert signature(store.at(minute).record) == oracle_signature(expected_store), (case, minute, "store")
            counts["store_snapshot_comparisons"] += 1
            prior_refreshes = [at for at in refreshes if at <= minute]
            capture_at = max(prior_refreshes) if prior_refreshes else None
            expected_cache = None if capture_at is None else oracle_store(expected_publications, sink_deliveries, capture_at)
            actual_cache = cache.at(minute)
            assert signature(actual_cache.record) == oracle_signature(expected_cache), (case, minute, "cache")
            assert actual_cache.captured_at == capture_at, (case, minute, "capture time")
            counts["cache_snapshot_comparisons"] += 1
        for left, right in zip(store.accepted, store.accepted[1:]):
            assert left[1].revision < right[1].revision, (case, "sink regression")
            counts["sink_monotonic_transitions_checked"] += 1
        counts["generated_cases"] += 1
    return {"seed": seed, "counts": dict(sorted(counts.items())), "status": "passed"}


if __name__ == "__main__":
    print(canonical_json(run_checks()), end="")
