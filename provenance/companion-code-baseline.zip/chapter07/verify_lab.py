"""Run tests and regenerate reports, without rewriting expected snapshots."""
from io import StringIO
import json
from pathlib import Path
import sys
import unittest

from backfill_lab import local_runtime
from examples import example_report
from printed_examples import run_examples
from randomized_checks import run_checks

ROOT = Path(__file__).parent


def encoded(value: object) -> str:
    return json.dumps(value, indent=2, sort_keys=True) + "\n"


def main() -> None:
    runtime = local_runtime()
    generated = ROOT / "generated"
    generated.mkdir(exist_ok=True)
    suite = unittest.defaultTestLoader.discover(str(ROOT), "test_*.py")
    capture = StringIO()
    result = unittest.TextTestRunner(stream=capture, verbosity=2).run(suite)
    (generated / "unittest.log").write_text(capture.getvalue(), encoding="utf-8")
    if not result.wasSuccessful():
        print(capture.getvalue(), file=sys.stderr)
        raise SystemExit("Unit tests failed; inspect generated/unittest.log")
    reports = {"examples.json": example_report(),
               "printed_examples.json": run_examples(),
               "randomized_checks.json": run_checks()}
    matching = []
    for name, report in reports.items():
        actual_text = encoded(report)
        (generated / name).write_text(actual_text, encoding="utf-8")
        expected = json.loads((ROOT / "expected_outputs" / name).read_text(encoding="utf-8"))
        actual = dict(report)
        if name == "randomized_checks.json":
            # Exact patch is recorded in every real dataset identity and this
            # report. Only this metadata field may differ across Python 3.12
            # installations; all semantic/check-count outputs still match.
            if actual.pop("runtime") != runtime:
                raise SystemExit("Generated report runtime is inconsistent")
            expected.pop("runtime")
        if encoded(actual) != encoded(expected):
            raise SystemExit(f"Snapshot mismatch: {name}; investigate, do not auto-bless")
        matching.append(name)
    summary = {"status": "passed", "runtime": runtime,
               "unit_tests_run": result.testsRun,
               "unit_test_failures": len(result.failures),
               "unit_test_errors": len(result.errors),
               "printed_snippets_executed": reports["printed_examples.json"]["snippets_executed"],
               "matching_snapshot_files": matching,
               "snapshot_metadata_excluded": ["randomized_checks.json:runtime"],
               "generated_checks": reports["randomized_checks.json"],
               "scope": "synthetic, single-process local staging and release simulation"}
    output = encoded(summary)
    (generated / "verification.json").write_text(output, encoding="utf-8")
    print(output, end="")


if __name__ == "__main__":
    main()
