"""Verify in a fresh temporary copy; never rewrite expected answers.

Default mode copies source, fixtures and expected outputs into a clean
directory, discarding generated output and bytecode, then runs all checks.
It copies new reports back only after the clean run succeeds.
"""
import argparse
import csv
import hashlib
from io import StringIO
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

ROOT = Path(__file__).parent


def encoded(value: object) -> str:
    return json.dumps(value, indent=2, sort_keys=True) + "\n"


def verify_hashes() -> int:
    count = 0
    for line in (ROOT / "SHA256SUMS.txt").read_text("utf-8").splitlines():
        expected, name = line.split("  ", 1)
        path = ROOT / name
        if not path.is_relative_to(ROOT) or ".." in Path(name).parts:
            raise AssertionError("invalid integrity path")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise AssertionError(f"file integrity mismatch: {name}")
        count += 1
    return count


def verify_in_place() -> dict:
    if sys.version_info[:2] != (3, 12):
        raise SystemExit("This lab is verified for Python 3.12; use that minor version.")
    from examples import example_report
    from exercise_answers import answer_report
    from fault_testing_lab import mutation_report
    from printed_examples import run_examples
    from randomized_checks import run_checks

    file_count = verify_hashes()
    generated = ROOT / "generated"
    generated.mkdir(exist_ok=True)
    suite = unittest.defaultTestLoader.discover(str(ROOT), "test_*.py")
    capture = StringIO()
    result = unittest.TextTestRunner(stream=capture, verbosity=2).run(suite)
    (generated / "unittest.log").write_text(capture.getvalue(), "utf-8")
    if not result.wasSuccessful():
        raise AssertionError(capture.getvalue())
    reports = {"examples.json": example_report(),
               "mutation_report.json": mutation_report(),
               "exercise_answers.json": answer_report(),
               "printed_examples.json": run_examples(),
               "randomized_checks.json": run_checks()}
    for name, report in reports.items():
        actual = encoded(report)
        (generated / name).write_text(actual, "utf-8")
        expected = json.loads((ROOT / "expected_outputs" / name).read_text("utf-8"))
        if actual != encoded(expected):
            raise AssertionError(f"snapshot mismatch: {name}; investigate, do not auto-bless")
    matrix = reports["mutation_report.json"]
    with (generated / "detection_matrix.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["check", *matrix["implementations"]])
        for name, row in matrix["matrix"].items():
            writer.writerow([name, *(row[impl] for impl in matrix["implementations"])])
    summary = {"status": "passed", "python": sys.version.split()[0],
               "isolated_clean_copy": False,
               "integrity_files_verified": file_count,
               "unit_tests_run": result.testsRun,
               "unit_test_failures": len(result.failures),
               "unit_test_errors": len(result.errors),
               "printed_snippets_executed": reports["printed_examples.json"]["snippets_executed"],
               "matching_snapshot_files": list(reports),
               "mutation_suite_results": matrix["suite_results"],
               "generated_checks": reports["randomized_checks.json"],
               "scope": "local synthetic contract and selected-fault evidence; no production execution"}
    (generated / "verification.json").write_text(encoded(summary), "utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--in-place", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.in_place:
        print(encoded(verify_in_place()), end="")
        return
    with TemporaryDirectory(prefix="chapter8-clean-") as temp:
        clean = Path(temp) / "lab"
        shutil.copytree(ROOT, clean, ignore=shutil.ignore_patterns(
            "__pycache__", "*.pyc", "generated", "clean_run_report.json"))
        environment = dict(os.environ)
        environment.pop("PYTHONPATH", None)
        environment["PYTHONDONTWRITEBYTECODE"] = "1"
        completed = subprocess.run([sys.executable, "-B", "verify_lab.py", "--in-place"],
            cwd=clean, env=environment, capture_output=True, text=True)
        if completed.returncode:
            print(completed.stdout, end="", file=sys.stderr)
            print(completed.stderr, end="", file=sys.stderr)
            raise SystemExit(completed.returncode)
        summary = json.loads(completed.stdout)
        summary["isolated_clean_copy"] = True
        shutil.copytree(clean / "generated", ROOT / "generated", dirs_exist_ok=True)
        (ROOT / "generated" / "verification.json").write_text(encoded(summary), "utf-8")
        print(encoded(summary), end="")


if __name__ == "__main__":
    main()
