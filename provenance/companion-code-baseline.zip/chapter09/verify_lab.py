"""Verify hashes, tests, exact listings, fixtures, and reports in a clean copy."""
from __future__ import annotations
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def verify(output_dir: Path) -> dict:
    if sys.version_info[:2] != (3, 12):
        raise RuntimeError("Use Python 3.12 for the verified lab contract")
    entries = []
    for line in (ROOT / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", 1)
        file = ROOT / name
        if file.resolve().parent != ROOT and ROOT not in file.resolve().parents:
            raise AssertionError("manifest path escapes lab")
        if sha256(file.read_bytes()).hexdigest() != expected:
            raise AssertionError(f"file hash mismatch: {name}")
        entries.append(name)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONHASHSEED="0")
    with tempfile.TemporaryDirectory(prefix="chapter9-clean-") as temporary:
        clean = Path(temporary) / "lab"
        clean.mkdir()
        for name in entries:
            dest = clean / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / name, dest)

        def run(*args):
            result = subprocess.run([sys.executable, "-B", *args], cwd=clean, env=env,
                                    capture_output=True, text=True, timeout=60)
            if result.returncode:
                raise AssertionError(result.stdout + result.stderr)
            return result

        # unittest counts are explicit; elapsed time and temporary paths never
        # enter the persisted deterministic verification report.
        runner = """import json,sys,unittest
suite=unittest.defaultTestLoader.discover('.', pattern='test_*.py')
result=unittest.TextTestRunner(verbosity=0).run(suite)
print(json.dumps({'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors)}))
sys.exit(not result.wasSuccessful())
"""
        tests = json.loads(run("-c", runner).stdout)
        first = run("operations_lab.py", "--output-dir", "run_a").stdout
        second = run("operations_lab.py", "--output-dir", "run_b").stdout
        if first != second:
            raise AssertionError("CLI summary is nondeterministic")
        report_names = ("base_report.json", "evidence_packet.json")
        hashes = {}
        for name in report_names:
            a = (clean / "run_a" / name).read_bytes()
            if a != (clean / "run_b" / name).read_bytes():
                raise AssertionError(f"report is nondeterministic: {name}")
            if a != (clean / "expected_outputs" / name).read_bytes():
                raise AssertionError(f"expected report mismatch: {name}")
            hashes[name] = sha256(a).hexdigest()
        snippets = json.loads(run("printed_examples.py").stdout)
        if snippets != json.loads((clean / "expected_outputs" / "printed_examples.json").read_text()):
            raise AssertionError("listing fixture mismatch")
        if any(clean.rglob("__pycache__")):
            raise AssertionError("clean run wrote unexpected bytecode")
        output_dir.mkdir(parents=True, exist_ok=True)
        for name in report_names:
            shutil.copyfile(clean / "run_a" / name, output_dir / name)
        result = {"status": "PASS", "runtime_contract": "Python 3.12 standard library only",
                  "clean_copy": True, "files_hash_verified": len(entries), **tests,
                  "standalone_listings": len(snippets), "two_report_runs_byte_identical": True,
                  "report_sha256": hashes, "external_actions": False}
        (output_dir / "verification.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return result


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "generated")
    args = parser.parse_args()
    print(json.dumps(verify(args.output_dir.resolve()), indent=2, sort_keys=True))
