"""Verify the package and regenerate all results in two clean ZIP extractions."""
from __future__ import annotations

from hashlib import sha256
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
SUMS = "SHA256SUMS"


def inventory(root: Path) -> set[str]:
    return {path.relative_to(root).as_posix() for path in root.rglob("*")
            if path.is_file() and "generated" not in path.relative_to(root).parts
            and "__pycache__" not in path.relative_to(root).parts
            and path.suffix != ".pyc"
            and path.relative_to(root).as_posix() != SUMS}


def verify(output_dir: Path = ROOT / "generated") -> dict:
    environment = json.loads((ROOT / "environment.json").read_text(encoding="utf-8"))
    if (platform.python_implementation() != environment["implementation"]
            or platform.python_version() != environment["verified_python_version"]):
        raise RuntimeError("Use the verified CPython 3.12.14 runtime")
    hashes = {}
    for line in (ROOT / SUMS).read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", 1)
        relative = PurePosixPath(name)
        if relative.is_absolute() or ".." in relative.parts or name in hashes:
            raise AssertionError("unsafe or duplicate checksum path")
        path = ROOT / name
        if path.is_symlink() or not path.is_file():
            raise AssertionError(f"missing/nonregular package file: {name}")
        if sha256(path.read_bytes()).hexdigest() != expected:
            raise AssertionError(f"package file hash mismatch: {name}")
        hashes[name] = expected
    if set(hashes) != inventory(ROOT):
        raise AssertionError("package inventory differs from SHA256SUMS")
    vendor = json.loads((ROOT / "vendor_manifest.json").read_text(encoding="utf-8"))
    for name, metadata in vendor["files"].items():
        if hashes.get(name) != metadata["sha256"]:
            raise AssertionError(f"vendor identity mismatch: {name}")
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONHASHSEED="0",
               PYTHONPATH="", PYTHONNOUSERSITE="1")
    results = []
    artifacts = {}
    with tempfile.TemporaryDirectory(prefix="chapter10-clean-") as temporary:
        temporary = Path(temporary)
        archive = temporary / "lab.zip"
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
            for name in sorted(set(hashes) | {SUMS}):
                bundle.write(ROOT / name, name)
        for run_number in (1, 2):
            clean = temporary / f"clean_{run_number}"
            with zipfile.ZipFile(archive) as bundle:
                bundle.extractall(clean)

            def execute(*arguments: str) -> subprocess.CompletedProcess:
                result = subprocess.run([sys.executable, "-B", *arguments], cwd=clean,
                                        env=env, capture_output=True, text=True,
                                        timeout=60)
                if result.returncode:
                    raise AssertionError(result.stdout + result.stderr)
                return result

            tests = execute("-m", "unittest", "discover", "-s", ".",
                            "-p", "test_*.py", "-v")
            match = re.search(r"Ran (\d+) tests?", tests.stderr)
            if not match or "skipped=" in tests.stderr:
                raise AssertionError("test population was not fully executed")
            summary = {"tests_run": int(match.group(1)), "case_runs": {}}
            for name in ("base", "challenge"):
                output = execute("capstone_lab.py", "--case", name,
                                 "--output-dir", f"generated/{name}")
                summary["case_runs"][name] = json.loads(output.stdout)
                for path in sorted((clean / "generated" / name).iterdir()):
                    relative = f"{name}/{path.name}"
                    raw = path.read_bytes()
                    expected = (clean / "expected_outputs" / relative).read_bytes()
                    if raw != expected:
                        raise AssertionError(f"expected artifact mismatch: {relative}")
                    if run_number == 1:
                        artifacts[relative] = raw
                    elif raw != artifacts[relative]:
                        raise AssertionError(f"two clean runs differ: {relative}")
            for command, fixture in (
                    ("printed_examples.py", "printed_examples.json"),
                    ("exercise_answers.py", "exercise_answers.json"),
                    ("randomized_checks.py", "randomized_checks.json")):
                output = execute(command)
                actual = json.loads(output.stdout)
                expected = json.loads((clean / "expected_outputs" / fixture).read_text(
                    encoding="utf-8"))
                if actual != expected:
                    raise AssertionError(f"expected executable output mismatch: {command}")
                summary[command] = actual
            example = execute("-c", "\n".join((
                "from capstone_lab import build_dataset, load_case, persist_run",
                "case = load_case('challenge')",
                "print(build_dataset(case)[1]['value'])",
                "result = persist_run(case, 'generated/my_new_run')",
                "print(result['status'])")))
            if example.stdout != "100\nPASS\n":
                raise AssertionError("README Python usage example mismatch")
            if any(clean.rglob("__pycache__")):
                raise AssertionError("clean run unexpectedly wrote bytecode")
            results.append(summary)
    if results[0] != results[1]:
        raise AssertionError("clean command summaries differ")
    result = {"status": "PASS", "runtime": environment,
              "package_files_hash_verified": len(hashes),
              "vendor_files_byte_verified": len(vendor["files"]),
              "tests_run_per_clean_copy": results[0]["tests_run"],
              "clean_zip_extractions": 2,
              "two_clean_runs_byte_identical": True,
              "artifact_files_compared_per_clean_run": len(artifacts),
              "artifact_sha256": {name: sha256(raw).hexdigest()
                                  for name, raw in artifacts.items()},
              "standalone_listings": len(results[0]["printed_examples.py"]),
              "chapter_exercises": len(results[0]["exercise_answers.py"]),
              "generated_checks": results[0]["randomized_checks.py"],
              "readme_cli_commands_and_python_example": "PASS",
              "external_actions": False}
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "verification.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return result


if __name__ == "__main__":
    print(json.dumps(verify(), indent=2, sort_keys=True))
