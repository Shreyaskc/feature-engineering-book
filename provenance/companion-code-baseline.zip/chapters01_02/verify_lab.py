"""Recompute the lab, run tests, and check tracked expected JSON reports.

The expected snapshots are never rewritten by this verifier. A mismatch
is an error to investigate, not permission to bless new expected values.
"""

from io import StringIO
import json
from pathlib import Path
import sys
import unittest

from foundations_lab import example_report
from printed_examples import run_examples
from randomized_checks import run_checks

ROOT = Path(__file__).parent


def encoded(data: dict) -> str:
    return json.dumps(data, indent=2, sort_keys=True) + "\n"


def main() -> None:
    generated = ROOT / "generated"
    generated.mkdir(exist_ok=True)
    suite = unittest.defaultTestLoader.discover(str(ROOT), "test_*.py")
    capture = StringIO()
    result = unittest.TextTestRunner(stream=capture, verbosity=2).run(suite)
    (generated / "unittest.log").write_text(capture.getvalue(), encoding="utf-8")
    if not result.wasSuccessful():
        print(capture.getvalue(), file=sys.stderr)
        raise SystemExit("Unit tests failed; inspect generated/unittest.log")

    reports = {"examples.json": example_report(),
               "printed_examples.json": run_examples(),
               "randomized_checks.json": run_checks()}
    comparisons = []
    for name, report in reports.items():
        actual = encoded(report)
        (generated / name).write_text(actual, encoding="utf-8")
        expected = (ROOT / "expected_outputs" / name).read_text(encoding="utf-8")
        if actual != expected:
            raise SystemExit(f"Snapshot mismatch: {name}; inspect both files")
        comparisons.append(name)
    summary = {
        "status": "passed",
        "unit_tests_run": result.testsRun,
        "unit_test_failures": len(result.failures),
        "unit_test_errors": len(result.errors),
        "printed_snippets_executed": reports["printed_examples.json"][
            "snippets_executed"],
        "matching_snapshot_files": comparisons,
        "generated_checks": reports["randomized_checks.json"],
        "scope": "synthetic arithmetic and in-memory contract validation",
    }
    text = encoded(summary)
    (generated / "verification.json").write_text(text, encoding="utf-8")
    print(text, end="")


if __name__ == "__main__":
    main()
