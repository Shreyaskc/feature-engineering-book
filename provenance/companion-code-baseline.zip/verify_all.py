"""Verify the selected companion release offline in isolated, clean processes.

The all-suite default executes nine distinct lab suites for ten chapters.
Every suite is run in two clean ZIP extractions; counts are reported once.
No shipped chapter source, expected result, or recorded report is rewritten.
"""
from __future__ import annotations
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
ORDER = ('chapters01_02', *(f'chapter{n:02}' for n in range(3, 11)))
ENVIRONMENT = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0',
                   PYTHONPATH='', PYTHONNOUSERSITE='1', PYTHONOPTIMIZE='')


def encoded(value):
    return json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def safe_path(root, name):
    rel = PurePosixPath(name)
    require(name and rel.parts and name == rel.as_posix()
            and not rel.is_absolute() and '..' not in rel.parts
            and '\\' not in name and ':' not in rel.parts[0],
            f'unsafe package path: {name}')
    path = root / name
    require(not any(part.is_symlink() for part in (path, *path.parents)),
            f'symlink in package path: {name}')
    require(path.resolve().is_relative_to(root.resolve()),
            f'package path escapes root: {name}')
    return path


def inventory():
    return {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*')
            if p.is_file() and p.relative_to(ROOT).parts[0] != 'generated'
            and '__pycache__' not in p.parts and p.suffix != '.pyc'
            and p.relative_to(ROOT).as_posix() != 'SHA256SUMS'}


def checksum_file(root, filename):
    identities = {}
    for line in (root / filename).read_text(encoding='utf-8').splitlines():
        expected, name = line.split('  ', 1)
        require(re.fullmatch('[0-9a-f]{64}', expected), 'invalid SHA256')
        require(name not in identities, f'duplicate checksum path: {name}')
        path = safe_path(root, name)
        require(path.is_file(), f'missing checksum file: {name}')
        require(sha256(path.read_bytes()).hexdigest() == expected,
                f'file integrity mismatch: {path.relative_to(ROOT)}')
        identities[name] = expected
    return identities


def verify_integrity():
    entries = checksum_file(ROOT, 'SHA256SUMS')
    require(set(entries) == inventory(), 'package inventory differs from SHA256SUMS')
    manifest = json.loads((ROOT / 'SOURCE_ARCHIVES.json').read_text())
    require(manifest['schema_version'] == 2, 'unsupported source manifest schema')
    require(set(manifest['archives']) == set(ORDER), 'incomplete chapter inventory')
    revisions = json.loads((ROOT / 'REVISIONS.json').read_text())
    require(revisions['schema_version'] == 1, 'unsupported revision manifest schema')
    require(revisions['baseline_companion'] == manifest['baseline_companion'], 'baseline provenance differs')
    require(set(revisions['chapters']) == set(ORDER) == set(manifest['original_archives']),
            'incomplete historical chapter inventory')
    approved = {'chapter03', 'chapter04', 'chapter06', 'chapter09', 'chapter10'}
    require(set(revisions['approved_revised_chapters']) == approved, 'unapproved revision scope')
    chapter_checksums = {}
    totals = dict.fromkeys(('original', 'selected', 'unchanged', 'changed', 'added', 'removed'), 0)
    for folder in ORDER:
        entry = manifest['archives'][folder]
        require(entry['file_count'] == len(entry['files']), 'invalid source file count')
        actual = {p.relative_to(ROOT / folder).as_posix() for p in (ROOT / folder).rglob('*')
                  if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
        require(actual == set(entry['files']), f'selected chapter inventory differs: {folder}')
        for name, identity in entry['files'].items():
            raw = safe_path(ROOT / folder, name).read_bytes()
            require(len(raw) == identity['size_bytes'] and sha256(raw).hexdigest() == identity['sha256'],
                    f'selected source member differs: {folder}/{name}')
        change = revisions['chapters'][folder]
        original = manifest['original_archives'][folder]
        require(change['original_archive'] == original and change['selected_archive'] == entry,
                f'revision archive identity differs: {folder}')
        old, new = original['files'], entry['files']
        require(original['file_count'] == len(old), 'invalid historical source count')
        common = old.keys() & new.keys()
        changed = sorted(name for name in common if (old[name]['sha256'], old[name]['size_bytes']) != (new[name]['sha256'], new[name]['size_bytes']))
        unchanged = sorted(common - set(changed))
        expected = {
            'added': [{'path': name, 'selected': new[name]} for name in sorted(new.keys() - old.keys())],
            'changed': [{'path': name, 'original': old[name], 'selected': new[name]} for name in changed],
            'removed': [{'path': name, 'original': old[name]} for name in sorted(old.keys() - new.keys())],
            'unchanged_paths': unchanged,
            'counts': {'original': len(old), 'selected': len(new), 'unchanged': len(unchanged),
                       'changed': len(changed), 'added': len(new.keys() - old.keys()), 'removed': len(old.keys() - new.keys())}}
        require(all(change[key] == value for key, value in expected.items()), f'revision member classification differs: {folder}')
        if folder not in approved:
            require(not changed and not expected['added'] and not expected['removed']
                    and original['source_archive_sha256'] == entry['source_archive_sha256'],
                    f'unapproved chapter drift: {folder}')
        for key, value in expected['counts'].items():
            totals[key] += value
        local_manifest = 'SHA256SUMS' if folder == 'chapter10' else 'SHA256SUMS.txt'
        chapter_checksums[folder] = len(checksum_file(ROOT / folder, local_manifest))
    require(totals == revisions['counts'] == manifest['revision_counts'], 'revision totals differ')
    return manifest, {'root_files_sha256_verified': len(entries),
                      'selected_source_archive_member_files_verified': totals['selected'],
                      'unchanged_original_member_files_verified': totals['unchanged'],
                      'revision_counts': totals,
                      'chapter_checksum_entries': chapter_checksums,
                      'source_archive_hashes': 'Selected and historical ZIP identities are recorded provenance; source ZIPs are not required or bundled.'}


def execute(cwd, *args):
    completed = subprocess.run([sys.executable, '-B', *args], cwd=cwd,
                               env=ENVIRONMENT, capture_output=True, text=True,
                               timeout=300)
    require(completed.returncode == 0,
            f'{cwd.name}: command failed ({completed.returncode}): {args}\n'
            + completed.stdout + completed.stderr)
    return completed


def unit_tests(cwd):
    result = execute(cwd, '-m', 'unittest', 'discover', '-s', '.', '-p', 'test_*.py', '-v')
    match = re.search(r'Ran (\d+) tests?', result.stderr)
    require(match and 'skipped=' not in result.stderr, 'test population not fully executed')
    return int(match.group(1)), result.stderr


def equal_bytes(actual, expected, label):
    require(actual == expected, f'exact output differs: {label}')
    return sha256(actual).hexdigest()


def legacy_adapter(cwd, folder):
    """Run the older README commands without modifying their source files."""
    counts, test_log = unit_tests(cwd)
    hashes = {}
    before = {}
    if folder == 'chapter04':
        names = ('dataset_rows.json', 'dataset_manifest.json')
        before = {name: (cwd / name).read_bytes() for name in names}
        output = execute(cwd, 'chapter4.py')
        hashes['stdout'] = equal_bytes(output.stdout.encode(), (cwd / 'expected_output.json').read_bytes(), 'Chapter 4 console')
        for name in names:
            hashes[name] = equal_bytes((cwd / name).read_bytes(), before[name], name)
        listings = execute(cwd, 'printed_examples.py').stdout
        equal_bytes(listings.encode(), b'All five printed Python listings passed.\n', 'Chapter 4 listings')
        original = execute(cwd, 'sample3_original_check.py').stdout
        equal_bytes(original.encode(), b'Original Chapter 3 function passed five direct assertions.\n', 'Chapter 3 legacy regression')
        result = {'unit_tests_run': counts, 'printed_snippets_executed': 5,
                  'legacy_sample_direct_assertions': 5,
                  'scope_note': 'Chapter 4 includes historical-feature regressions; these are not added to a book-wide unique-test total.'}
    elif folder == 'chapter05':
        names = ('comparison.json', 'policy_manifest.json')
        before = {name: (cwd / name).read_bytes() for name in names}
        output = execute(cwd, 'chapter5.py')
        hashes['stdout'] = equal_bytes(output.stdout.encode(), (cwd / 'expected_output.json').read_bytes(), 'Chapter 5 console')
        for name in names:
            hashes[name] = equal_bytes((cwd / name).read_bytes(), before[name], name)
        listings = execute(cwd, 'printed_examples.py').stdout
        equal_bytes(listings.encode(), b'All six printed Python listings passed.\n', 'Chapter 5 listings')
        generated = execute(cwd, 'randomized_checks.py').stdout
        match = re.search(r'PASS: seeds (\d+)\.\.(\d+); (\d+) fixtures; (\d+) policy cases; (\d+) emitted snapshots checked', generated)
        require(match is not None, 'missing Chapter 5 generated-check population')
        require(tuple(map(int, match.groups())) == (0, 499, 500, 1000, 1396), 'Chapter 5 generated counts differ')
        result = {'unit_tests_run': counts, 'printed_snippets_executed': 6,
                  'generated_checks': {'seed_start': 0, 'seed_end': 499, 'fixtures': 500, 'policy_cases': 1000, 'emitted_snapshots_checked': 1396}}
    elif folder == 'chapter06':
        before = {name: (cwd / 'generated' / name).read_bytes() for name in ('manifest.json', 'parity_report.json')}
        output = execute(cwd, 'parity_lab.py')
        hashes['stdout'] = equal_bytes(output.stdout.encode(), (cwd / 'expected_outputs/parity_report.json').read_bytes(), 'Chapter 6 console')
        for name, original in before.items():
            hashes['generated/' + name] = equal_bytes((cwd / 'generated' / name).read_bytes(), original, name)
        fixture_code = '''from dataclasses import asdict
from parity_lab import build_fixture, canonical_json
trace, _ = build_fixture()
fixture = dict(contracts=asdict(trace.contracts), key=asdict(trace.key),
               publications=[asdict(row) for row in trace.publications],
               source_revisions=[asdict(row) for row in trace.source.revisions])
print(canonical_json(fixture), end='')
'''
        fixture = execute(cwd, '-c', fixture_code).stdout
        hashes['fixture'] = equal_bytes(fixture.encode(), (cwd / 'expected_outputs/fixture.json').read_bytes(), 'Chapter 6 source/publication fixture')
        reports = {}
        for name in ('printed_examples', 'randomized_checks'):
            report = execute(cwd, name + '.py').stdout
            hashes[name] = equal_bytes(report.encode(), (cwd / 'expected_outputs' / (name + '.json')).read_bytes(), name)
            reports[name] = json.loads(report)
        result = {'unit_tests_run': counts, 'printed_snippets_executed': len(reports['printed_examples']),
                  'generated_checks': reports['randomized_checks']}
    else:
        raise RuntimeError('No legacy adapter for ' + folder)
    return {'status': 'PASS', **result, 'exact_output_sha256': hashes}, test_log


def run_once(cwd, folder):
    if folder in ('chapter04', 'chapter05', 'chapter06'):
        return legacy_adapter(cwd, folder)
    completed = execute(cwd, 'verify_lab.py')
    result = json.loads(completed.stdout)
    require(str(result.get('status')).lower() in ('pass', 'passed'), 'verifier did not report PASS')
    if folder == 'chapter09':
        answers = execute(cwd, 'exercise_answers.py').stdout
        equal_bytes(answers.encode(), (cwd / 'expected_outputs/exercise_answers.json').read_bytes(), 'Chapter 9 exercises')
        result['chapter_exercises'] = len(json.loads(answers))
    return result, completed.stderr


def run_chapter(folder, entry, output_dir):
    results = []
    with tempfile.TemporaryDirectory(prefix='feature-companion-') as temporary:
        temp = Path(temporary)
        archive = temp / 'chapter.zip'
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
            for name in sorted(entry['files']):
                bundle.write(ROOT / folder / name, name)
        with zipfile.ZipFile(archive) as bundle:
            require(bundle.testzip() is None, 'temporary archive CRC failure')
            for number in (1, 2):
                clean = temp / f'clean_{number}'
                # Names are validated against the selected source manifest.
                bundle.extractall(clean)
                result, stderr = run_once(clean, folder)
                require(not any(clean.rglob('__pycache__')), 'unexpected generated bytecode')
                results.append(result)
                target = output_dir / folder
                target.mkdir(parents=True, exist_ok=True)
                if (clean / 'generated').is_dir():
                    shutil.copytree(clean / 'generated', target / f'run_{number}', dirs_exist_ok=True)
                if folder in ('chapter04', 'chapter05'):
                    retained = ('dataset_rows.json', 'dataset_manifest.json') if folder == 'chapter04' else ('comparison.json', 'policy_manifest.json')
                    artifact_dir = target / f'run_{number}'
                    artifact_dir.mkdir(exist_ok=True)
                    for name in retained:
                        shutil.copyfile(clean / name, artifact_dir / name)
                (target / f'run_{number}.json').write_text(encoded(result), encoding='utf-8')
                (target / f'run_{number}.stderr.txt').write_text(stderr, encoding='utf-8')
    require(results[0] == results[1], f'{folder}: two clean result summaries differ')
    result = results[0]
    count = next((result[k] for k in ('unit_tests_run', 'tests_run', 'tests_run_per_clean_copy') if k in result), None)
    require(type(count) is int and count > 0, f'{folder}: missing executed unit-test population')
    return {'folder': folder, 'status': 'PASS', 'clean_extractions': 2,
            'two_clean_summary_results_equal': True,
            'unit_tests_per_suite': count, 'chapter_result': result}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--chapter', choices=[f'{n:02}' for n in range(1, 11)],
                        help='run one chapter; 01 and 02 share one foundations suite')
    parser.add_argument('--integrity-only', action='store_true',
                        help='verify all shipped file identities without running lab code')
    args = parser.parse_args()
    output_dir = ROOT / 'generated'
    output_dir.mkdir(exist_ok=True)
    report_name = 'integrity' if args.integrity_only else (args.chapter or 'all')
    target = output_dir / ('verification_' + report_name + '.json')
    # Replace any prior PASS immediately so a failed rerun leaves no stale success.
    target.write_text(encoded({'status': 'RUNNING'}), encoding='utf-8')
    try:
        require(sys.flags.optimize == 0, 'Assertion checks require Python without -O/-OO')
        require(platform.python_implementation() == 'CPython' and platform.python_version() == '3.12.14',
                'Use the verified CPython 3.12.14 runtime')
        require(sqlite3.sqlite_version == '3.53.1',
                'Exact Chapter 4 environment output requires SQLite 3.53.1 (via sqlite3)')
        manifest, integrity = verify_integrity()
        selected = (('chapters01_02' if args.chapter in ('01', '02') else 'chapter' + args.chapter),) if args.chapter else ORDER
        results = []
        if not args.integrity_only:
            for folder in selected:
                print(f'Verifying {folder} ...', file=sys.stderr, flush=True)
                results.append(run_chapter(folder, manifest['archives'][folder], output_dir))
        result = {'status': 'PASS', 'runtime': {'implementation': platform.python_implementation(),
                  'python': platform.python_version(), 'sqlite': sqlite3.sqlite_version},
                  'integrity': integrity, 'distinct_lab_suites_executed': len(results),
                  'chapters': results, 'external_actions': False,
                  'counting_rule': 'Per-suite populations only. Repeated clean runs, shared Chapters 1–2, vendored modules and overlapping semantic checks are not summed as unique tests.'}
        target.write_text(encoded(result), encoding='utf-8')
        print(encoded(result), end='')
        return 0
    except Exception as error:
        result = {'status': 'FAIL', 'error': str(error)}
        target.write_text(encoded(result), encoding='utf-8')
        print(encoded(result), file=sys.stderr, end='')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
